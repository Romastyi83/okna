const choce = document.querySelector('[data-choice]');
const choices = new Choices(choce, {
  searchEnabled: false,
  itemSelectText: ""
})

const choceModal = document.querySelector('[data-choice-modal]');
const choicesModal = new Choices(choceModal, {
  searchEnabled: false,
  itemSelectText: ""
})