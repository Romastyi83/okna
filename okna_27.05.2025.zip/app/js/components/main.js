const swiper = new Swiper('[data-swiper]', {
  slidesPerView: "auto",
  spaceBetween: 20,
  pagination: {
    el: ".swiper-pagination",
    clickable: true,
  },
  breakpoints: {
    1200: {
      loop: true,
      autoplay: {
        enabled: true,
        delay: 3500,
      }
    }
  },
});

const swiperPortfolio = new Swiper('[data-swiper-portfolio]', {
  slidesPerView: "auto",
  spaceBetween: 21,
  breakpoints: {
    320: {
      spaceBetween: 16
    },
    851: {
      spaceBetween: 21
    }
  },
});


const body = document.body;
const showPopup = document.querySelectorAll('[data-show-popup]');
const layoutPopup = document.querySelector('[data-layout-popup]');
const popup = document.querySelector('[data-popup]');
showPopup.forEach(item => {
  item.addEventListener('click', (e) => {
    e.preventDefault();
    layoutPopup.classList.add('active');
    if (!popup.classList.contains('active')) {
      popup.classList.add('active')
    }
    if (!body.classList.contains('modal__open')) {
      body.classList.add('modal__open')
    }
  })
})
document.addEventListener('click', (e) => {
  if ((e.target === document.querySelector('[data-close-popup]')) || (e.target === layoutPopup)) {
    layoutPopup.classList.remove('active');
    body.classList.remove('modal__open');
  }
})

const door1 = document.querySelector('[data-door-1]');
const door2 = document.querySelector('[data-door-2]');
const door3 = document.querySelector('[data-door-3]');
const door4 = document.querySelector('[data-door-4]');
const door5 = document.querySelector('[data-door-5]');
const door6 = document.querySelector('[data-door-6]');
const door7 = document.querySelector('[data-door-7]');
const door8 = document.querySelector('[data-door-8]');
const door9 = document.querySelector('[data-door-9]');
const door10 = document.querySelector('[data-door-10]');
const door11 = document.querySelector('[data-door-11]');


function slideDoor() {
  door5.classList.add('door--slide-5');
  door6.classList.add('door--slide-6');
  door7.classList.add('door--slide-7');
  setTimeout(() => {
    door3.classList.add('door--slide-3');
    door4.classList.add('door--slide-4');
    door8.classList.add('door--slide-8');
    door9.classList.add('door--slide-9');
  }, 2000);
  setTimeout(() => {
    door1.classList.add('door--slide-1');
    door2.classList.add('door--slide-2');
    door10.classList.add('door--slide-10');
    door11.classList.add('door--slide-11');
  }, 4000);
  setTimeout(() => {
    door1.classList.remove('door--slide-1');
    door2.classList.remove('door--slide-2');
    door3.classList.remove('door--slide-3');
    door4.classList.remove('door--slide-4');
    door5.classList.remove('door--slide-5');
    door6.classList.remove('door--slide-6');
    door7.classList.remove('door--slide-7');
    door8.classList.remove('door--slide-8');
    door9.classList.remove('door--slide-9');
    door10.classList.remove('door--slide-10');
    door11.classList.remove('door--slide-11');
  }, 6000);
}
setTimeout(() => {
  setInterval(slideDoor, 9000);
}, 2000);

const door1Mob = document.querySelector('[data-door-1-mob]');
const door2Mob = document.querySelector('[data-door-2-mob]');
const door3Mob = document.querySelector('[data-door-3-mob]');
const door4Mob = document.querySelector('[data-door-4-mob]');
const door5Mob = document.querySelector('[data-door-5-mob]');
const door6Mob = document.querySelector('[data-door-6-mob]');
const door7Mob = document.querySelector('[data-door-7-mob]');
const door8Mob = document.querySelector('[data-door-8-mob]');
const door9Mob = document.querySelector('[data-door-9-mob]');
const door10Mob = document.querySelector('[data-door-10-mob]');
const door11Mob = document.querySelector('[data-door-11-mob]');

function slideDoorMob() {
  door5Mob.classList.add('door--slide-5');
  door6Mob.classList.add('door--slide-6');
  door7Mob.classList.add('door--slide-7');
  setTimeout(() => {
    door3Mob.classList.add('door--slide-3');
    door4Mob.classList.add('door--slide-4');
    door8Mob.classList.add('door--slide-8');
    door9Mob.classList.add('door--slide-9');
  }, 2000);
  setTimeout(() => {
    door1Mob.classList.add('door--slide-1');
    door2Mob.classList.add('door--slide-2');
    door10Mob.classList.add('door--slide-10');
    door11Mob.classList.add('door--slide-11');
  }, 4000);
  setTimeout(() => {
    door1Mob.classList.remove('door--slide-1');
    door2Mob.classList.remove('door--slide-2');
    door3Mob.classList.remove('door--slide-3');
    door4Mob.classList.remove('door--slide-4');
    door5Mob.classList.remove('door--slide-5');
    door6Mob.classList.remove('door--slide-6');
    door7Mob.classList.remove('door--slide-7');
    door8Mob.classList.remove('door--slide-8');
    door9Mob.classList.remove('door--slide-9');
    door10Mob.classList.remove('door--slide-10');
    door11Mob.classList.remove('door--slide-11');
  }, 6000);
}
setTimeout(() => {
  setInterval(slideDoorMob, 9000);
}, 2000);

const mobMenu = document.querySelector('[data-menu]');
const mobMenuBtn = document.querySelector('[data-menu-btn]');
const mobMenuX = document.querySelector('[data-menu-x]');

document.addEventListener('click', (e) => {
  if ((e.target === mobMenuBtn)) {
    mobMenu.classList.add('active');
  }
})

document.addEventListener('click', (e) => {
  if ((e.target === mobMenuX)) {
    mobMenu.classList.remove('active');
  }
})

const mobItem = document.querySelector('[data-mobile-item]');

document.addEventListener('click', (e) => {
  if ((e.target === mobItem)) {
    if (!mobItem.nextElementSibling.classList.contains('active')) {
      mobItem.nextElementSibling.classList.add('active')
    }
    else {
      mobItem.nextElementSibling.classList.remove('active')
    }
  }
})